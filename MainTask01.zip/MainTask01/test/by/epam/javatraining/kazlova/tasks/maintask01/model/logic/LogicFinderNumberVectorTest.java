package by.epam.javatraining.kazlova.tasks.maintask01.model.logic;

import static org.junit.Assert.*;

import org.junit.Test;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;
import by.epam.javatraining.kazlova.tasks.maintask01.model.logic.LogicFinderNumberVector;

public class LogicFinderNumberVectorTest {

	/** the test to find the maximum element */
	@Test
	public void testFindMaxElement() {
		double[] array = { 1, 4, 3 };
		NumberVector numberVector = new NumberVector(array);
		double expected = 4.0;
		assertEquals(expected, LogicFinderNumberVector.findMaxElement(numberVector), 0.0);
	}

	/** the test to find the minimum element */
	@Test
	public void testFindMinElement() {
		double[] array = { 1, 4, 3 };
		NumberVector numberVector = new NumberVector(array);
		double expected = 1.0;
		assertEquals(expected, LogicFinderNumberVector.findMinElement(numberVector), 0.0);
	}

	/** the test to find the vector's average */
	@Test
	public void testFindVectorAverage() {
		double[] array = { 1, 2, 3 };
		NumberVector numberVector = new NumberVector(array);
		double expected = 2.0;
		assertEquals(expected, LogicFinderNumberVector.findVectorAverage(numberVector), 0.0);

	}

	/** the test to find the vector's geometric */
	@Test
	public void testFindVectorGeometric() {
		double[] array = { 3, 3, 3 };
		NumberVector numberVector = new NumberVector(array);
		double expected = 3;
		assertEquals(expected, LogicFinderNumberVector.findVectorGeometric(numberVector), 0.0);

	}

	/**
	 * the test to check whether all elements of the vector are in an ordered form
	 */
	@Test
	public void testCheckOrderedFormOfVector() {
		double[] array = { 1, 2, 3 };
		NumberVector numberVector = new NumberVector(array);
		assertTrue(LogicFinderNumberVector.checkOrderedFormOfVector(numberVector));
	}

}
