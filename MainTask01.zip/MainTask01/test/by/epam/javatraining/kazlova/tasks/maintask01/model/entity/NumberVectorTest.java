package by.epam.javatraining.kazlova.tasks.maintask01.model.entity;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;


public class NumberVectorTest {
	@Test
	public void testNumberVectorWithoutParameters() {
		final int DEFAULT_SIZE = 2;
		double [] expected = {0,0};
		assertEquals(expected, new NumberVector() );
	}
	@Test
	public void testGetArray() {
		NumberVector numberVector = new NumberVector();
		double [] expected  = { 1, 4, 3 };
		assertEquals(expected, NumberVector.getArray());
	}
}
