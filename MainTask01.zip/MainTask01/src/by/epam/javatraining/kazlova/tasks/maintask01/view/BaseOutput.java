package by.epam.javatraining.kazlova.tasks.maintask01.view;

public abstract class BaseOutput {
	public abstract void print(String str);
}