package by.epam.javatraining.kazlova.tasks.maintask01.model.logic;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;

public class LogicSorterNumberVector {

	/** bubble vector sorting */

	public static void bubbleSorterNumberVector(NumberVector numberVector) {
		double var = 0;
		for (int i = 0; i < numberVector.getArray().length - 1; i++) {
			for (int j = 0; j < numberVector.getArray().length - 1 - i; j++) {
				if (numberVector.getElement(j) > numberVector.getElement(j + 1)) {
					var = numberVector.getElement(j);
					numberVector.setElement(j, numberVector.getElement(j));
					numberVector.setElement(j + 1, var);
				}
			}
		}
	}

	/** insertion vector sorting */
	public static void insertionSorterNumberVector(NumberVector numberVector) {
		double var = 0;
		int k = 0;

		for (int i = 1; i < numberVector.getArray().length; ++i) {
			var = numberVector.getElement(i);
			k = i - 1;

			while (k >= 0 && numberVector.getElement(k) > var) {
				numberVector.setElement(k + 1, numberVector.getElement(k));
				k = k - 1;
			}
			numberVector.setElement(k + 1, var);
		}
	}
}
