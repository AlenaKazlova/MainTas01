package by.epam.javatraining.kazlova.tasks.maintask01.view;

import org.apache.log4j.Logger;

public class LogOutput extends BaseOutput {
	private static final Logger LOG = Logger.getRootLogger();

	public void print(String str) {
		LOG.info(str);
	}
}
