package by.epam.javatraining.kazlova.tasks.maintask01.util;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;
import java.util.Random;

public class Creator {
	public static NumberVector randomCreate() {
		Random random = new Random();
		double[] arr = new double[random.nextInt()];
		NumberVector numberVector = new NumberVector(arr);
		return numberVector;
	}

	public static NumberVector userCreate(IInput inputtt) {
		double[] arr = new double[inputtt.readInt()];
		NumberVector numberVector = new NumberVector(arr);
		return numberVector;
	}
}
