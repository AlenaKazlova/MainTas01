package by.epam.javatraining.kazlova.tasks.maintask01.util;

import java.util.Random;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;

public class Inizialaser {
	public static void randomInit(NumberVector numberVector, double maxValue) {
		Random random = new Random();
		for (int i = 0; i < numberVector.getArray().length; i++) {
			numberVector.setElement(i, random.nextDouble());
		}
	}

	public static void userInit(NumberVector numberVector, IInput input) {
		for (int i = 0; i < numberVector.getArray().length; i++) {
			numberVector.setElement(i, input.readDouble());
		}
	}
}
