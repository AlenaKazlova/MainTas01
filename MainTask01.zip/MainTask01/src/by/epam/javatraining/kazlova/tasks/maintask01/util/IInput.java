package by.epam.javatraining.kazlova.tasks.maintask01.util;

public interface IInput {

	double readDouble();

	int readInt();
}
