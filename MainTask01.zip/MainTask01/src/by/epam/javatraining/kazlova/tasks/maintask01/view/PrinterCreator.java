package by.epam.javatraining.kazlova.tasks.maintask01.view;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;

public class PrinterCreator {

	public static BaseOutput create(int type) {
		BaseOutput printer;

		switch (type) {
		case 1:
			printer = new FileOutput();
			break;
		case 2:
			printer = new ConsoleOutput();
			break;
		default:
			printer = new LogOutput();
		}

		return printer;
	}

	public static void print(NumberVector numberVector) {
		
	}
}
