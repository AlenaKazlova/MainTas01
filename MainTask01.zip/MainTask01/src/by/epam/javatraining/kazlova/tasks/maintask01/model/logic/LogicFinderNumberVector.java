package by.epam.javatraining.kazlova.tasks.maintask01.model.logic;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;

public class LogicFinderNumberVector {

	/** to find the maximum element */

	public static double findMaxElement(NumberVector numberVector) {
		double max = numberVector.getArray()[0];

		if (numberVector.getArray().length > 0) {
			for (double value : numberVector.getArray()) {
				if (value > max) {
					max = value;
				}
			}
		}
		return max;
	}

	/** to find the minimum element */
	public static double findMinElement(NumberVector numberVector) {
		double min = numberVector.getElement(0);

		for (int i = 0; i < numberVector.getArray().length; i++) {
			if (numberVector.getElement(i) < min) {
				min = numberVector.getElement(i);
			}
		}

		return min;
	}

	/** to find the vector's average */
	public static double findVectorAverage(NumberVector numberVector) {
		double average = 0;

		for (double element : numberVector.getArray()) { // doubleVector.getArray()???
			average += element;
		}

		return average / numberVector.getArray().length;
	}

	/** to find the vector's geometric */
	public static double findVectorGeometric(NumberVector numberVector) {
		double geometric = 1;

		for (double element : numberVector.getArray()) {
			geometric *= element;
		}
		return Math.pow(geometric, 1. / numberVector.getArray().length);
	}

	/** check whether all elements of the vector are in an ordered form */
	public static boolean checkOrderedFormOfVector(NumberVector numberVector) {
		boolean isOrdered = true;

		for (int i = 0; i < numberVector.getArray().length - 1; i++) {

			if (numberVector.getElement(i) > numberVector.getElement(i + 1)) {
				isOrdered = false;
				break;
			}
		}

		return isOrdered;
	}

	/** to find the vector's local minimum index */
	public static int findLocaLMinIndex(NumberVector numberVector) {
		int key = -1;

		if (numberVector.getElement(0) < numberVector.getElement(1)) {
			key = 0;
		} else {
			for (int i = 1; i < numberVector.getArray().length - 1; i++) {
				if (numberVector.getElement(i) < numberVector.getElement(i - 1)
						&& numberVector.getElement(i) < numberVector.getElement(i + 1)) {
					key = i;
					break;
				}
			}
		}

		if (numberVector.getElement(numberVector.getArray().length - 1) < numberVector
				.getElement(numberVector.getArray().length - 2)) {
			key = numberVector.getArray().length - 1;
		}

		return key;
	}

	/** finding the vector's local maximum index */
	public static int findLocaLMaxIndex(NumberVector numberVector) {
		int key = -1;
		if (numberVector.getElement(0) > numberVector.getElement(1)) {
			key = 0;
		} else {
			for (int i = 1; i < numberVector.getArray().length - 1; i++) {
				if (numberVector.getElement(i) > numberVector.getElement(i - 1)
						&& numberVector.getElement(i) > numberVector.getElement(i + 1)) {
					key = i;
					break;
				}
			}
		}

		if (numberVector.getElement(numberVector.getArray().length - 1) > numberVector
				.getElement(numberVector.getArray().length - 2)) {
			key = numberVector.getArray().length - 1;
		}

		return key;
	}
}
