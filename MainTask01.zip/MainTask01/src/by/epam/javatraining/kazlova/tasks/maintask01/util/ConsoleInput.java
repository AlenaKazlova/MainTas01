package by.epam.javatraining.kazlova.tasks.maintask01.util;

import by.epam.javatraining.kazlova.tasks.maintask01.util.IInput;

public class ConsoleInput implements IInput {

	@Override
	public double readDouble() {

		return 0;
	}

	@Override
	public int readInt() {

		return 0;
	}

}
