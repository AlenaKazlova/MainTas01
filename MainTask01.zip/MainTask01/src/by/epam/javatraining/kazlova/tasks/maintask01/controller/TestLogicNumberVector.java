package by.epam.javatraining.kazlova.tasks.maintask01.controller;

import by.epam.javatraining.kazlova.tasks.maintask01.util.ConsoleInput;
import by.epam.javatraining.kazlova.tasks.maintask01.util.Creator;
import by.epam.javatraining.kazlova.tasks.maintask01.util.IInput;
import by.epam.javatraining.kazlova.tasks.maintask01.util.Inizialaser;
import by.epam.javatraining.kazlova.tasks.maintask01.view.BaseOutput;
import by.epam.javatraining.kazlova.tasks.maintask01.view.LogOutput;
import by.epam.javatraining.kazlova.tasks.maintask01.view.PrinterCreator;
import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;
import by.epam.javatraining.kazlova.tasks.maintask01.model.logic.LogicFinderNumberVector;
import by.epam.javatraining.kazlova.tasks.maintask01.model.logic.LogicSorterNumberVector;

import java.util.Random;

public class TestLogicNumberVector {
	public static void main(String[] args) {
		final int OUTPUT = 1;

		NumberVector numberVector = Creator.randomCreate();
		Inizialaser.randomInit(numberVector, 10);

		IInput consoleInput = new ConsoleInput();
		Inizialaser.userInit(numberVector, consoleInput);

		double max = LogicFinderNumberVector.findMaxElement(numberVector);
		BaseOutput printer = PrinterCreator.create(OUTPUT);
		PrinterCreator.print(str);

		PrinterCreator.print(numberVector);
		PrinterCreator.print("Max= " + max);

		PrinterCreator.print(numberVector);
		LogicSorterNumberVector.bubbleSorterNumberVector(numberVector);
		PrinterCreator.print(numberVector);

	}
}
