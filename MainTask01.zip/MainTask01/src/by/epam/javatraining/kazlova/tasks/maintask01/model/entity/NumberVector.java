package by.epam.javatraining.kazlova.tasks.maintask01.model.entity;

public class NumberVector {
	public static final int DEFAULT_SIZE = 10;

	private static double[] array;

	public NumberVector() {
		array = new double[DEFAULT_SIZE];
	}

	public NumberVector(int size) {
		array = new double[size];
	}

	public NumberVector(double[] array) {
		this.array = array;
	}

	public void setArray(double[] array) {
		this.array = array;
	}

	public static double[] getArray() {
		return array;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("DoubleVector {");

		for (double d : array) {
			builder.append(d).append(" ");
		}

		builder.append("}");

		return builder + "";

	}

	public double getElement(int index) {

		return array[index];
	}

	public double setElement(int index, double value) {
		return array[index];
	}

}
