package by.epam.javatraining.kazlova.tasks.maintask01.model.logic;

import java.util.Arrays;

import by.epam.javatraining.kazlova.tasks.maintask01.model.entity.NumberVector;

public class LogicSearchNumberVector {
	/** linear search element */
	public static int linearSerchNumberVectorElement(NumberVector numberVector, double searchItem) {
		int key = -1;
		for (int i = 0; i < numberVector.getArray().length; i++) {
			if (numberVector.getElement(i) == searchItem) {
				key = i;
				break;
			}
		}
		return key;
	}

	/**
	 * binary search element The binary search is working only for sorted vector
	 */
	public static int binarySerchNumberVectorElement(NumberVector numberVector, double searchItem) {
		Arrays.sort(numberVector.getArray());
		int key = -1;

		int start = 0;
		int end = numberVector.getArray().length - 1;

		while (start <= end) {
			int mid = (start + end) / 2;

			if (numberVector.getElement(mid) == searchItem) {
				key = mid;
				break;
			} else {
				if (numberVector.getElement(mid) < searchItem) {
					start = mid + 1;
				} else {
					end = mid - 1;
				}
			}
		}
		return key;
	}
}
