package by.epam.javatraining.kazlova.tasks.maintask01.view;

public class ConsoleOutput extends BaseOutput {
	@Override
	public void print(String s) {
		System.out.println(s);
	}
}
