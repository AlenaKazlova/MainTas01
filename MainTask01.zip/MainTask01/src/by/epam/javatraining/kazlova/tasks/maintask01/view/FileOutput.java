package by.epam.javatraining.kazlova.tasks.maintask01.view;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class FileOutput extends BaseOutput {

	public static String fileName;

	@Override
	public void print(String str) {
		File file = new File(fileName);

		try {

			if (!file.exists()) {
				file.createNewFile();
			}

			PrintWriter out = new PrintWriter(file.getAbsoluteFile());

			try {

				out.print(str);
			} finally {
				out.close();
			}
		} catch (IOException e) {

			throw new RuntimeException(e);
		}
	}
}
